#Q1

##Setting Directory
setwd("C:\\Users\\it24101304\\Desktop\\Lab 4")
##Importing the data set
branch_data<-read.table("Exercise.txt", header=TRUE, sep = ",")
##view the file in a separate window
attach (data)

#Q2
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1, main="Sales",ylab="Sales_X1")

#Q4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q5

outlier <- function(x){
  Q1<- quantile(x,0.25)
  Q3<- quantile(x,0.75)
  IQR<-Q3-Q1
  lower<-Q1 -1.5*IQR
  upper<-Q3 +1.5*IQR
  y <- x[x<lower | x>upper]
  return (y)
}

outlier(branch_data$Years_X3)